## Windows 10 Automation using Java + TestNG

**TODO:**
- Download the project files and import to intellij or eclipse .
- Download the project's dependecies (as described at the buttom of the readme). 
- Change to your Perfecto lab username, password and host at Win10Calaculator.java file . 
- Run using testNG from the testNG.xml file.

### Required dependecies: 
- Selenium jars and Selenium standalone required and can be downloaded from [here](http://www.seleniumhq.org/download/) .
- TestNG usually already included in intellij and eclipse , yet it can be downloaded from [here](http://testng.org/doc/download.html). 

Read more about windows 10 automation at our [community](https://community.perfectomobile.com/posts/1199190-windows-10-testing-on-surface-pro) .
