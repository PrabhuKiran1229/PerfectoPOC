## Window10 Native Automation Using C # #

The Perfecto plugin for Visual Studio supports running an automation script for a Windows 10 app directly on a Surface Pro 4 device connected to the Perfecto Lab.

The following samples shows how to use C# in order to execute automation tests on this devices.

Read more about this code sample in our [community](https://community.perfectomobile.com/posts/1201497-automating-the-windows-10-calculator?video_markers=surface) . 
