## Test windows 10 device using C# NUnit framework . 

This code sample shows how to test Windows 10 device using C# NUnit framework. 

**TODO:**
- Download the project and import into visual studio. 
- Make sure Perfecto plugin is installed, it can be found [here](https://www.perfectomobile.com/download-integrations).
- Set your Perfecto lab user,pass and host at the test file.
- Run as NUnit test. 

For more support check out our [community](https://community.perfectomobile.com/)
