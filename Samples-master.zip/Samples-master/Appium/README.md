##Appium Driver For Native App Automation

This section contains Appium Driver code samples for Native application automation using different programming languages such as Java, C#, Python and Ruby.<br/>
It's recommended to follow the tests stracture and use test frameworks in order to keep the test stability. 

**Prerequisites:**
- Download and install Appium Driver from [here](http://appium.io/downloads.html).
- It's recommended to use Perfecto plugin for Visual Studio / Eclipse / Intellij , Download from [here](https://www.perfectomobile.com/download-integrations).
