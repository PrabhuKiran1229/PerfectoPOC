#IMDb Application code sample.

:information_source: This test requires the IMDb application, which can be found [here](https://github.com/PerfectoCode/AppsForSamples/tree/master/IMDb).

**TODO:**
- To use this code sample, make sure that the IMDb application is already installed on the device before running the test.
- Change you device name and platformName at testng.xml file.
- Change User,Pass,Cloud information at the test class : IMDBappium.java .
- Run as testNG from the testng.xml file.
