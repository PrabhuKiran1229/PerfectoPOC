##WebDriverIO Searching in google

This code sample shows how to use WebDriverIO in order to locate and click elements.

**TODO**
- Download the script.
- Set your Perfecto lab User,Pass and Host.
- Run using NodeJS on the command line: node filename.js