## Selenium code samples using JavaScript

These code sampels show how to build a test using Javascript and test frameworks such as Mocha and Jasmine. 

**Downloads:**
- Download Selenium WebDriver for Java script [here](http://www.seleniumhq.org/download/) . 
