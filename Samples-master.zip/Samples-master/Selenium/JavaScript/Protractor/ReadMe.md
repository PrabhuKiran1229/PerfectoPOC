##Protractor Sample

This code sample shows how to use Protractor and Jasmine framework in order to execute JavaScript test.

**TODO:**
- Download the test files: conf.js and spec.js.
- Make sure you have installed [Protractor](http://www.protractortest.org/#/) and [Jasmine](http://jasmine.github.io/) framework.
- Set your Perfecto lab Host, User and Password in the conf.js file.
- Execute the test via command line with: protractor spec.js.

Read more about Protractor in our [community](https://community.perfectomobile.com/posts/1209188)
