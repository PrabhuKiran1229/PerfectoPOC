#Selenium Python Automation

**To do**:
- Downlaod the .rb files .
- Replace My-Host with your cloud host.
- Replace My_User at capabilities_hash with your cloud user.
- Replace My_Password at capabilities_hash with your cloud password.
- Replace Device name or add another capabilities.
