# Ruby Sample

**TO DO:**
- Download the Ruby test.
- Change Hostname , user and password.
- Run this as a test as a regular ruby script (Ruby filename.rb). 
