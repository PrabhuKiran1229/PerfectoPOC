#Selenium c# Automation

**To do**:
- Downlaod and import the projecto to visual studio.
- Replace My_Host at RemoteWebDriverTest.cs with your cloud's host name.
- Replace My_User at RemoteWebDriverTest.cs with your cloud user.
- Replace My_Pass at RemoteWebDriverTest.cs with your cloud password.
