# C# Sample

**TO DO:**
- Create a C# project on visual studio (Test project or use [Perfecto plugin](https://www.perfectomobile.com/download-integrations) to create a Perfecto's project).
- Copy this test to the main test unit.
- Change Hostname , user and password.
- Run this as a test (Right click and Run Tests or Ctrl+R) .
