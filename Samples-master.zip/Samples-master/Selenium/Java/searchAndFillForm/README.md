# Java Sample

**TO DO:**
- Create a new Java project (use [Perfecto plugin](https://www.perfectomobile.com/download-integrations) to create a perfecto project).
- Copy this test to the main test unit or src folder.
- Change Hostname , user and password.
- Run this test as a regular java application.
