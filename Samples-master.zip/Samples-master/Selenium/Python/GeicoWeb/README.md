#Selenium Python Automation

**To do**:
- Downlaod the .py file .
- Run from command line (or using Jenkins arguments) with : Python GeicoTest.py My_User My_Pass My_Host
