# Python Sample

**TO DO:**
- Create a Python project using your desired IDE ([Eclipse pydev](http://marketplace.eclipse.org/node/114) + [Perfecto plugin](https://www.perfectomobile.com/download-integrations) project is recommended!).
- Copy this test to the main test unit.
- Change Hostname, user and password.
- Compile and run RemoteWebDriverTest.py (Using: python filename.py or via IDE). 
