#Selenium
The Perfecto Selenium server is an extension of the existing Selenium server, enabling a single test for both mobile browsers and desktop browsers

You can find different project and code samples related to Selenium in this repository.

To learn more on Perfecto Selenium, access the [Selenium RemoteWebDriver Guide](https://community.perfectomobile.com/posts/915148-selenium-remotewebdriver)
