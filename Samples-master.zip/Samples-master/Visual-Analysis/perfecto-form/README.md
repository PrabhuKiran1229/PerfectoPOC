##Fill Form Using Visual Analysis
This code sample shows how to locate elements and insert text using Perfecto visual analysis.

Note that this sample using images from Chrome Browser different browser may require a new images! 

**TODO:**
- Import the project to Eclipse or Intellij as Maven Project.
- Set your Perfecto lab User, Password and Cloud's Host at driverCreator.Java file.
- Set your desktop device capabilities at testng.xml.
- Upload the test images (from VisualAnalysis Pics directory) to your repository.
- Update the test images path at Perfecto_VisualAnalysis.java file.
- Run the project as TestNG test via testng.xml file.

For more info about Maven click [here](https://community.perfectomobile.com/posts/915224-working-with-maven)

For more info about TestNG click [here](https://community.perfectomobile.com/posts/988612-manage-testng-execution-and-data)
