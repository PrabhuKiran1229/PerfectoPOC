#Amazon Cross-Platform test Python

**To do**:
- Download the .py files.
- Replace My_User with your could user at TestParameters.py.
- Replace My_Pass with your cloud password at TestParameters.py.
- Replace other tests parameters at TestParameters.py.