"""
Here goes the test parameters . 
TODO: Replace hardcoded with sys.args
"""

#Host information:
host        = 'My_Host.perfectomobile.com'
token       = 'My_Token'

#Application information:
AppUser     = 'My_AppUser'
AppPass     = 'My_AppPass'
YourName    = 'My_Name'
searchValue = 'Pink Floyd'

#devices information:
iPhone_6 = {
            'token': token,
            'deviceName': 'My Device Name'
}

desktop_chome = {
                 'token': token,
                 'platformName': 'Windows',
                 'platformVersion': '7',
                 'browserName': 'Chrome',
                 'browserVersion': '49'
}