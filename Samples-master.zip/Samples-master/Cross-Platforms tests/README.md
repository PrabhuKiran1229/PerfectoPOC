#Cross-Platform tests

In this section you can find tests which include Multiple Platforms (mobile & desktop) sessions.
The tests include two or more devices in the same scenario and intagrated with different languages test frameworks. 

**Prerequisite:**
- [Selenium](www.seleniumhq.org/download/) and [Appium](http://appium.io/downloads.html) installed in your favorite programming language.
- Using Perfecto plugins for Eclipse / Intellij / Visual Studio is recommended !!! and can download from [here](https://www.perfectomobile.com/download-integrations).

Follow our [community](community.perfectomobile.com) to find more code samples and ask questions.
