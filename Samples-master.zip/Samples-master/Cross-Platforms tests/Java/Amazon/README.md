#Amazon Cross-Platform test Java

**To do**:
- Import the project as Maven project.
- Replace devices capabilities at conf.xml file.
- Replace My_User with your could user at Properties.java.
- Replace My_Pass with your cloud password at Properties.java.
- Replace other tests parameters at Properties.java.
