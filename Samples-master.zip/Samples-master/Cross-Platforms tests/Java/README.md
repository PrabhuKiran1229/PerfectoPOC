#Cross-Platforms Tests in java.

Maven projects , testNG test framework and more code samples in java.

Also:
See example [here](https://github.com/PerfectoCode/Samples/tree/master/Visual-Analysis/maps-web) for another cross platform testing sample using Perfecto's Visual Analysis.
