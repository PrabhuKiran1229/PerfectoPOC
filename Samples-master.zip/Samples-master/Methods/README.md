## Methods code samples

This sub-project contains different methods implementations using Selenium and Appium drivers in different languages.

Find more samples and ask questions at our [community](https://community.perfectomobile.com/).
