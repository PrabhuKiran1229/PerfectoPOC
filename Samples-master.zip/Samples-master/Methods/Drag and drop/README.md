# Drag and drop sample
This code sample shows how to implement a drag and drop action on desktop. 

**To do**:
- Import the project as a Maven Project
- Specify your target Web machines IDs or Capabilities in the testng.xml file
- Specify your cloud , user and password at src/test/java/DragAndDropSample.java
- Execute the test by right clicking the testng.xml file and selecting Run As/TestNG Suite.
