##Executing JavaScript From RemoteWebDriver

This code samples shows how to use Selenium WebDriver in order to execute JavaScript code in your test.

**TODO:**
- Choose a code sample in prefered language **Java** / **C#** / **Python** / **Ruby** .
- Set your Perfecto lab User, Password and Host.
- Set the device capabilities by your choice.
