:information_source: This test requires the Noom Weight application, which can be found [here](https://github.com/PerfectoCode/AppsForSamples/tree/master/Noom%20Weight).
